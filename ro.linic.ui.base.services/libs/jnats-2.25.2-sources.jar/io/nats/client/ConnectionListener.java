// Copyright 2015-2018 The NATS Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at:
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package io.nats.client;

/**
 * Applications can use a ConnectionListener to track the status of a {@link Connection Connection}. The 
 * listener is configured in the {@link Options Options} at creation time.
 */
public interface ConnectionListener {
    /**
     * Enum for connection events
     */
    enum Events {
        /** The connection has successfully completed the handshake with the nats-server. */
        CONNECTED(true, "opened"),
        /** The connection is permanently closed, either by manual action or failed reconnects. */
        CLOSED(true, "closed"),
        /** The connection lost its connection, but may try to reconnect if configured to. */
        DISCONNECTED(true, "disconnected"),
        /** The connection was connected, lost its connection and successfully reconnected. */
        RECONNECTED(true, "reconnected"),
        /** The connection was reconnected and the server has been notified of all subscriptions. */
        RESUBSCRIBED(false, "subscriptions re-established"),
        /** The connection was made aware of new servers from the current server connection. */
        DISCOVERED_SERVERS(false, "discovered servers"),
        /** Server Sent a lame duck mode. */
        LAME_DUCK(false, "lame duck mode");

        private final boolean connectionEvent;
        private final String event;
        private final String natsEvent;

        /**
         * Construct an events enum
         * @param connectionEvent whether this is a connection event
         * @param event the simple event text
         */
        Events(boolean connectionEvent, String event) {
            this.connectionEvent = connectionEvent;
            this.event = event;
            if (connectionEvent) {
                this.natsEvent = "nats: connection " + event;
            }
            else {
                this.natsEvent = "nats: " + event;
            }
        }

        /**
         * Whether this event is a connection event.
         * @return the flag
         */
        public boolean isConnectionEvent() {
            return connectionEvent;
        }

        /**
         * Get the simple event text
         * @return the text
         */
        public String getEvent() {
            return event;
        }

        /**
         * Get the event text calculated with if it's a connection event and prefixed with "nats:"
         * @return the text
         */
        public String getNatsEvent() {
            return natsEvent;
        }

        /**
         * @return the string value for this event
         */
        public String toString() {
            return this.natsEvent;
        }
    }

    /**
     * @deprecated use new api that gives additional details
     * Connection related events that occur asynchronously in the client code are
     * sent to a ConnectionListener via a single method. The ConnectionListener can
     * use the event type to decide what to do about the problem.
     *
     * @param conn the connection associated with the error
     * @param type the type of event that has occurred
     */
    @Deprecated
    void connectionEvent(Connection conn, Events type);

    /**
     * Connection related events that occur asynchronously in the client code are
     * sent to a ConnectionListener via a single method. The ConnectionListener can
     * use the event type to decide what to do about the problem.
     * @param conn the connection associated with the error
     * @param type the type of event that has occurred
     * @param time the time of the event, milliseconds since 1/1/1970
     * @param uriDetails extra details about the uri related to this connection event
     */
    default void connectionEvent(Connection conn, Events type, Long time, String uriDetails) {
        connectionEvent(conn, type);
    }
}
